#!/usr/bin/env python3
import json
import ipaddress
import sys

if sys.argv[1] == "":
    print("need subnet")
    exit(1)

ipnet = ipaddress.ip_network(sys.argv[1])

dns = []
for host in ipnet.hosts():
        records = []
        dns.append({
         'name': host.reverse_pointer,
         'type': 'PTR',
         'ttl': '300',
         'reverse': host.reverse_pointer,
         'records': ['ip-{}.dgtek.net.'.format(host)]
         })

print(json.dumps(dns))
